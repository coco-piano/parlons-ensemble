export default function Contact() {
  return (
    <div>
      <h2>Contact</h2>
      <p>Écrivez-nous à <a href="mailto:contact@parlonsensemble.com">contact@parlonsensemble.com</a></p>
    </div>
  );
}
