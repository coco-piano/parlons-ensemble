export default function About() {
  return (
    <div>
      <h2>À propos</h2>
      <p>Nous mettons en relation des personnes âgées avec des jeunes formés et bienveillants pour créer du lien humain.</p>
    </div>
  );
}
