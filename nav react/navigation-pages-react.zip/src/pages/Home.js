export default function Home() {
  return (
    <div>
      <h2>Bienvenue sur Parlons Ensemble</h2>
      <p>Des conversations chaleureuses avec des jeunes bienveillants.</p>
    </div>
  );
}
